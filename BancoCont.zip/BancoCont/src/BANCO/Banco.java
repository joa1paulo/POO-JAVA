package BANCO;

import java.util.ArrayList;

public class Banco {
    public ArrayList<Conta> contas = new ArrayList<>();

    void depositoCliente() {}
    void transferencia() {}

    void extratoCliente(String nomeBusca) {
        for (Conta c : contas) {
            if (c.cliente.nome.equalsIgnoreCase(nomeBusca)) {
                System.out.println("\n--- EXTRATO FINAL DE: " + c.cliente.nome + " ---");
                for (String op : c.cliente.operacoes) {
                    System.out.println(op);
                }
                return;
            }
        }
        System.out.println("Cliente não encontrado.");
    }
}