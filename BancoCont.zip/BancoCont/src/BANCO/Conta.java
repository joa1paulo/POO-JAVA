package BANCO;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Conta {
    public Cliente cliente; // Agora inicializado via construtor

    public Conta(Cliente cliente) {
        this.cliente = cliente;
    }

    String dataHora() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
    }

    void checarSaldo() {
        System.out.println("A conta corrente de " + cliente.nome + " tem: R$" + cliente.saldo);
        cliente.operacoes.add(dataHora() + ": Saldo verificado: R$" + cliente.saldo);
    }

    void depositarSaldo(double valor) {
        cliente.saldo += valor;
        cliente.operacoes.add(dataHora() + ": Depósito: R$" + valor + ". Novo saldo: R$" + cliente.saldo);
    }

    boolean retirarSaldo(double valor) {
        // Corrigido para >= (permitir sacar o que tem)
        if (cliente.especial || valor <= cliente.saldo) {
            cliente.saldo -= valor;
            cliente.operacoes.add(dataHora() + ": Saque: R$" + valor + ". Novo saldo: R$" + cliente.saldo);
            return true;
        } else {
            System.out.println("Saldo insuficiente.");
            return false;
        }
    }

    void transferirSaldoPara(double valor, Conta destinatario) {
        if (retirarSaldo(valor)) {
            destinatario.depositarSaldo(valor);
            cliente.operacoes.add(dataHora() + ": Transferência enviada para " + destinatario.cliente.nome + ": R$" + valor);
            destinatario.cliente.operacoes.add(dataHora() + ": Transferência recebida de " + cliente.nome + ": R$" + valor);
        }
    }
}