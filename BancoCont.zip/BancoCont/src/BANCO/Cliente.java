package BANCO;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
    public String nome;
    public String endereco;
    public double saldo;
    public boolean especial;
    public List<String> operacoes = new ArrayList<>();

    public Cliente(String nome, double saldo, boolean especial) {
        this.nome = nome;
        this.saldo = saldo;
        this.especial = especial;
    }
}