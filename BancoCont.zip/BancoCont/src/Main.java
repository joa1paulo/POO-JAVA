import APP.Aplicacao;

public class Main {
    public static void main(String[] args) {
        Aplicacao exec = new Aplicacao();
        exec.executar();
    }
}