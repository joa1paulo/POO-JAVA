package APP;
import BANCO.Banco;
import BANCO.Cliente;
import BANCO.Conta;
import java.util.Scanner;

public class Aplicacao { // Removido os () da classe
    Banco banco = new Banco();
    Scanner scanner = new Scanner(System.in);

    public void executar() {
        int opcao = 0;
        while (opcao != 7) {
            menuOperacoes();
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 -> novoCliente();
                case 2 -> depositarSaldo();
                case 3 -> retirarSaldo();
                case 4 -> infoCliente();
                case 5 -> transferencia();
                case 6 -> extratoContas();
                case 7 -> System.out.println("Encerrando sistema...");
                default -> System.out.println("Opção inválida!");
            }
        }
    }

    void menuOperacoes() {
        System.out.println("\n------- OPERACOES BANCO --------");
        System.out.println("ESCOLHA QUAL OPERACAO QUER FAZER:");
        System.out.println("1-CADASTRAR UM NOVO CLIENTE");
        System.out.println("2-DEPOSITAR SALDO EM UMA CONTA");
        System.out.println("3-RETIRAR SALDO DE UMA CONTA");
        System.out.println("4-CONFERIR SALDO/INFO");
        System.out.println("5-REALIZAR TRANSFERENCIA");
        System.out.println("6-CHECAR EXTRATO");
        System.out.println("7-SAIR");
    }

    void novoCliente() {
        System.out.println("Nome do cliente:");
        String nome = scanner.nextLine();
        System.out.println("Saldo inicial:");
        double saldo = scanner.nextDouble();
        System.out.println("É conta especial? (true/false):");
        boolean especial = scanner.nextBoolean();
        Cliente cliente = new Cliente(nome, saldo, especial);
        Conta novaConta = new Conta(cliente);
        banco.contas.add(novaConta);
        System.out.println("Cliente cadastrado com sucesso!");
    }

    void depositarSaldo() {}
    void retirarSaldo() {}
    void infoCliente() {}
    void transferencia() {}
    void extratoContas() {}
}